public abstract class Binop extends Op {
    public abstract double eval(double left, double right);
}